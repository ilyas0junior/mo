package org.example;

import org.example.entity.Produit;  // Importing the Produit entity class
import org.example.entity.ProduitBuilder;  // Importing the ProduitBuilder class for creating products
import org.example.entity.TypeProduit;  // Importing the TypeProduit enum for product types
import org.example.repository.ProduitRepositoryImpl;  // Importing the implementation of the product repository

import java.util.Date;  // Importing the Date class for managing dates
import java.util.List;  // Importing the List interface for handling collections of products
import java.util.Optional;  // Importing the Optional class for handling optional product results
import java.util.function.Predicate;  // Importing the Predicate interface for defining conditions on products

// Main class that contains the main method to execute the program
public class Main {
    public static void main(String[] args) {

        // Below lines are commented out. If they were uncommented, they would create a product using the builder pattern.
        /*Produit p1 = new ProduitBuilder()  // Create a new product using the builder pattern
                .ref(1L)  // Set the product reference (ID) to 1
                .nom("Yaourt")  // Set the product name to "Yaourt"
                .prix(10.23)  // Set the product price to 10.23
                .dateCreation(new Date())  // Set the product creation date to the current date
                .type(TypeProduit.Neutritif)  // Set the product type to "Neutritif"
                .build();  // Build and return the product object

        System.out.println(p1.toString());  // Print the string representation of the product*/

        // Create a singleton instance of the product repository implementation
        ProduitRepositoryImpl pri = ProduitRepositoryImpl.getInstence();  // Using the singleton pattern to get the single instance

        // Display all products in the repository
        System.out.println("=====================Afficher tous les produits===========================");
        List<Produit> prds = pri.findAll();  // Fetch all products from the repository
        for (Produit p : prds)  // Iterate over the list of products
            System.out.println(p.toString());  // Print each product's string representation

        // Add a new product to the repository
        System.out.println("=====================Ajouter un nouveau produit===========================");
        Produit p = new ProduitBuilder()  // Using the builder pattern to create a new product
                .nom("Lait")  // Set the name of the product to "Lait"
                .prix(10)  // Set the price of the product to 10
                .quantiteStock(500)  // Set the stock quantity of the product to 500
                .type(TypeProduit.Neutritif)  // Set the type of the product to "Neutritif"
                .build();  // Build the product object
        pri.save(p);  // Save the new product in the repository

        // Display all products after the new product is added
        for (Produit p1 : pri.findAll())
            System.out.println(p1.toString());  // Print each product's string representation

        // Search for a specific product by reference (ID)
        System.out.println("=====================Chercher un Produit===========================");
        Optional<Produit> prd = pri.finfByRef(4L);  // Search for a product with reference (ID) 4
        if (prd.isPresent())  // If the product is found
            System.out.println(prd.toString());  // Print the product's string representation

        // Modify an existing product
        System.out.println("=====================Modifier un Produit===========================");
        Produit p2 = new ProduitBuilder()  // Create a new product object to update the existing one
                .ref(4L)  // Set the reference (ID) of the product to 4 (the one to be updated)
                .nom("Lait")  // Set the name of the product to "Lait"
                .prix(13)  // Set the price of the product to 13
                .quantiteStock(1500)  // Set the stock quantity to 1500
                .type(TypeProduit.Neutritif)  // Set the type of the product to "Neutritif"
                .build();  // Build the updated product object
        pri.update(p2);  // Update the product in the repository

        // Display all products after the modification
        for (Produit p1 : pri.findAll())
            System.out.println(p1.toString());  // Print each product's string representation

        // Delete a product by reference (ID)
        System.out.println("=====================Supprimer un Produit===========================");
        pri.detele(4L);  // Delete the product with reference (ID) 4 from the repository

        // Display all products after deletion
        for (Produit p1 : pri.findAll())
            System.out.println(p1.toString());  // Print each product's string representation

        // Search for products based on specific criteria using a predicate
        System.out.println("=====================chercher un Produit===========================");
        List<Produit> prds1 = pri.search(
                new Predicate<Produit>() {  // Create a predicate to define the search criteria
                    @Override
                    public boolean test(Produit p) {
                        return (p.getType().equals(TypeProduit.Cosmitique)  // Product type is "Cosmetique"
                                && p.getQuantiteStock() > 80);  // Product has more than 80 in stock
                    }
                }
        );

        // Display the products that match the search criteria
        for (Produit p1 : prds1)
            System.out.println(p1.toString());  // Print each matching product's string representation
    }
}
