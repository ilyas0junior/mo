package org.example.entity;

import java.util.Date;  // Importing the Date class to handle date attributes

// The ProduitBuilder class follows the Builder design pattern to help create Produit objects easily.
public class ProduitBuilder {
    // Private fields that correspond to the attributes of the Produit class
    private Long ref;  // Product reference ID (unique identifier)
    private String nom;  // Name of the product
    private double prix;  // Price of the product
    private double quantiteStock;  // Stock quantity of the product
    private Date dateCreation;  // Creation date of the product
    private Date datePremption;  // Expiry date of the product
    private TypeProduit type;  // Type of the product (e.g., Neutritif, Cosmetique)

    // Method to set the reference ID (using method chaining)
    public ProduitBuilder ref(Long ref) {
        this.ref = ref;  // Set the reference ID
        return this;  // Return the builder object for method chaining
    }

    // Method to set the name of the product (using method chaining)
    public ProduitBuilder nom(String nom) {
        this.nom = nom;  // Set the product name
        return this;  // Return the builder object for method chaining
    }

    // Method to set the price of the product (using method chaining)
    public ProduitBuilder prix(double prix) {
        this.prix = prix;  // Set the product price
        return this;  // Return the builder object for method chaining
    }

    // Method to set the stock quantity of the product (using method chaining)
    public ProduitBuilder quantiteStock(double quantiteStock) {
        this.quantiteStock = quantiteStock;  // Set the stock quantity
        return this;  // Return the builder object for method chaining
    }

    // Method to set the creation date of the product (using method chaining)
    public ProduitBuilder dateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;  // Set the creation date
        return this;  // Return the builder object for method chaining
    }

    // Method to set the expiration date of the product (using method chaining)
    public ProduitBuilder datePremption(Date datePremption) {
        this.datePremption = datePremption;  // Set the expiration date
        return this;  // Return the builder object for method chaining
    }

    // Method to set the type of the product (using method chaining)
    public ProduitBuilder type(TypeProduit type) {
        this.type = type;  // Set the type of the product
        return this;  // Return the builder object for method chaining
    }

    // The build() method constructs and returns a new Produit object using the values set in the builder
    public Produit build() {
        // Create and return a new Produit object with the provided values
        return new Produit(ref, nom, prix, quantiteStock, dateCreation, datePremption, type);
    }
}
