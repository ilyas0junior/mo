package org.example.entity;

import java.util.Date;  // Importing the Date class to work with date objects

// The Produit class represents a product with various attributes such as reference, name, price, etc.
public class Produit {
    private Long ref;  // Product reference ID (unique identifier)
    private String nom;  // Name of the product
    private double prix;  // Price of the product
    private double quantiteStock;  // Stock quantity of the product
    private Date dateCreation;  // Creation date of the product
    private Date datePremption;  // Expiry date of the product (may not be applicable for all types)
    private TypeProduit type;  // Type of product (an enum that categorizes the product, e.g., "Neutritif", "Cosmetique")

    // Default constructor
    public Produit() {
    }

    // Parameterized constructor to initialize all attributes of the product
    public Produit(Long ref, String nom, double prix, double quantiteStock, Date dateCreation, Date datePremption, TypeProduit type) {
        this.ref = ref;  // Set the product reference ID
        this.nom = nom;  // Set the product name
        this.prix = prix;  // Set the product price
        this.quantiteStock = quantiteStock;  // Set the stock quantity
        this.dateCreation = dateCreation;  // Set the product creation date
        this.datePremption = datePremption;  // Set the product expiry date
        this.type = type;  // Set the product type
    }

    // Getter method for the reference ID
    public Long getRef() {
        return ref;
    }

    // Getter method for the product name
    public String getNom() {
        return nom;
    }

    // Getter method for the product price
    public double getPrix() {
        return prix;
    }

    // Getter method for the stock quantity
    public double getQuantiteStock() {
        return quantiteStock;
    }

    // Getter method for the product creation date
    public Date getDateCreation() {
        return dateCreation;
    }

    // Getter method for the product expiry date
    public Date getDatePremption() {
        return datePremption;
    }

    // Getter method for the product type (e.g., Neutritif, Cosmetique)
    public TypeProduit getType() {
        return type;
    }

    // Setter method for the reference ID
    public void setRef(Long ref) {
        this.ref = ref;
    }

    // Setter method for the product name
    public void setNom(String nom) {
        this.nom = nom;
    }

    // Setter method for the product price
    public void setPrix(double prix) {
        this.prix = prix;
    }

    // Setter method for the stock quantity
    public void setQuantiteStock(double quantiteStock) {
        this.quantiteStock = quantiteStock;
    }

    // Setter method for the product creation date
    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    // Setter method for the product expiry date
    public void setDatePremption(Date datePremption) {
        this.datePremption = datePremption;
    }

    // Setter method for the product type
    public void setType(TypeProduit type) {
        this.type = type;
    }

    // Overriding the toString method to return a string representation of the product object
    @Override
    public String toString() {
        return "Produit{" +
             
