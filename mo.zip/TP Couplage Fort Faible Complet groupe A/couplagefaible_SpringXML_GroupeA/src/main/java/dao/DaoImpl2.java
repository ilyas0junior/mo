package dao;

public class DaoImpl2 implements IDao {
	public double getData() {
		System.out.println("Version capture");
		double data=150;
		return data;
	}
}
