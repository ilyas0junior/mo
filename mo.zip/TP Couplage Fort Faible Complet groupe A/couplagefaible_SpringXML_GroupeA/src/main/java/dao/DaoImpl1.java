package dao;

public class DaoImpl1 implements IDao {
	
	public double getData() {
		System.out.println("Version base de donn�es");
		double data=100;
		return data;
	}

}
