package presentation;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.DaoImpl1;
import dao.DaoImpl2;
import dao.IDao;
import metier.IMetier;
import metier.MetierImpl1;

public class Application {

	public static void main(String[] args) {
		// dans src/main/java ca marche directement sans chemain
		// si non on utilise file:chemain  : voir exemple
		//ApplicationContext ctx = new ClassPathXmlApplicationContext("file:test/config.xml");
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
		IMetier metier = (IMetier) ctx.getBean("metier");
		System.out.println("le resultat et : "+ metier.calculer());
	}

}
