package metier;


import dao.IDao;

public class MetierImpl1 implements IMetier {

	// couplage faible
	
	private  IDao  dao=null;
	
		

	// setter
	public void setDao(IDao dao) {
		this.dao = dao;
	}
	
	// contructeur
//       public Metier(Dao1 dao) {
//		       //super();
//		    this.dao = dao;
//	       }


	public double calculer() {
		double data=dao.getData();
		double res=data*5;
		return res;
	}
	
}
