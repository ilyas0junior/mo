package dao;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

//@Component("dao1")
@Repository("dao1")
public class DaoImpl1 implements IDao {
	
	public double getData() {
		System.out.println("Version base de donn�es");
		double data=100;
		return data;
	}

}
