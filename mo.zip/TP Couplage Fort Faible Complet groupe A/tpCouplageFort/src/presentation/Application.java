package presentation;

import dao.Dao2;
import metier.Metier;

public class Application {

	public static void main(String[] args) {
		
		//creation de l'objet Dao1
		Dao2 dao=new Dao2();
		
		// creation de l'objet Metier
		Metier metier=new Metier();
		
		// creation de l'objet Metier avec dependance statique
		//  Metier metier=new Metier(dao);
		
		// injection de d�pendance sataique via setter
		 metier.setDao(dao);
		
		// affichage de r�sultat
		System.out.println("le r�sultat est : "+metier.calculer());
		

	}

}
