package ma.poly;

import ma.poly.composite.Dossier;
import ma.poly.composite.Fichier;

public class Application {
    public static void main(String[] args) {

       // creation de dossier racine
        Dossier root=new Dossier("/");
        root.addComposant(new Fichier("config.xml"));
        root.addComposant(new Fichier("examen.doc"));

        //creation de sous dossiers
        Dossier dao=new Dossier("dao");
        root.addComposant(dao);
        dao.addComposant(new Fichier("ProduitDao.java"));
        dao.addComposant(new Fichier("ClientDao.java"));
        //=====================================
        Dossier testDao=new Dossier("testDao");
        dao.addComposant(testDao);
        testDao.addComposant(new Fichier("test1.java"));
        testDao.addComposant(new Fichier("test2.java"));
       //=====================================
        Dossier entity=new Dossier("entity");
        root.addComposant(entity);
        entity.addComposant(new Fichier("Produit.java"));
        entity.addComposant(new Fichier("Client.java"));

        root.afficher();
    }
}