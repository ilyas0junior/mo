package ma.poly;

import ma.poly.composite.Box;
import ma.poly.composite.CompositeBox;
import ma.poly.composite.DeliveryService;
import ma.poly.composite.products.Book;
import ma.poly.composite.products.Electronic;

public class Client {

    public static void main(String[] args) {
        // creation de service de livraison
        DeliveryService ds=new DeliveryService();

        // preparer la commande
        ds.preparateOrder(

               new CompositeBox(
                       new Electronic("IPhone",15000),
                       new Electronic("Tablette",5800)
                    ) ,
                new CompositeBox(
                        new Book("comprendre XML",800),
                        new Book("comprendre Design Pattern",1200),
                        new Book("comprendre Java",600)
                ),
                new Book("Boite à Merveille",250)

        );

        // calculer et afficher le prix
        System.out.println("Tolat Price of Order is : "+ds.calculateOrderPrice()+" Dh");
    }
}