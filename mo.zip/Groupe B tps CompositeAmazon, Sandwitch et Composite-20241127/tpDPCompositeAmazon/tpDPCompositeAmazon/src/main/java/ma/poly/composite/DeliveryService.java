package ma.poly.composite;

public class DeliveryService {
    private Box box;

    public void preparateOrder(Box... boxes){
        this.box=new CompositeBox(boxes);
    }

    public double calculateOrderPrice(){
        return box.calculatePrice();
    }
}
