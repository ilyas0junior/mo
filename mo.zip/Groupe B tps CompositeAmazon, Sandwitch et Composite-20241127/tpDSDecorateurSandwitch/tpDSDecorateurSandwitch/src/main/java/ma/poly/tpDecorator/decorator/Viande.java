package ma.poly.tpDecorator.decorator;

import ma.poly.tpDecorator.Sandwitch;

public class Viande extends SandwitchDecorator{
    public Viande(Sandwitch sandwitch) {
        super(sandwitch);
    }

    @Override
    public double getCout() {
        return sandwitch.getCout()  +30;
    }

    public String getDescription(){

        return sandwitch.getDescription()+" Au Viande";
    }
}
